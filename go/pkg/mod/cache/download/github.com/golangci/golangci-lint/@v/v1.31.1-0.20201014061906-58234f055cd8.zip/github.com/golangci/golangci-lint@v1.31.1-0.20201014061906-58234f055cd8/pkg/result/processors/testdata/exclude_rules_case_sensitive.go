package testdata

//GO:generate long line that will be excluded by default processor but will not be affected by case-sensitive one because of capital GO

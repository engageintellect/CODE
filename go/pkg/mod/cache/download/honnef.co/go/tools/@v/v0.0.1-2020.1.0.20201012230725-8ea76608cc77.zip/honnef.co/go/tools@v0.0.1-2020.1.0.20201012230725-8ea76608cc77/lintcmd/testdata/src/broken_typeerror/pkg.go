package pkg

func fn() {
	x := 1
	_ = x + ""
}

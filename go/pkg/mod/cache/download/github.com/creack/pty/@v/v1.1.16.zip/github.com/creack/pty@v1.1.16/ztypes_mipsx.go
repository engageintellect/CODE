//go:build (mips || mipsle || mips64 || mips64le) && linux
//+build linux
//+build mips mipsle mips64 mips64le

// Created by cgo -godefs - DO NOT EDIT
// cgo -godefs types.go

package pty

type (
	_C_int  int32
	_C_uint uint32
)

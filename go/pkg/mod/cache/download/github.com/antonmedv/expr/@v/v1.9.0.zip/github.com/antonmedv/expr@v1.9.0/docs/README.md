# Documentation

* [Getting Started](Getting-Started.md)
* [Language Definition](Language-Definition.md)
* [Custom functions](Custom-Functions.md)
* [Operator Override](Operator-Override.md)
* [Visitor and Patch](Visitor-and-Patch.md)
* [Optimizations](Optimizations.md)

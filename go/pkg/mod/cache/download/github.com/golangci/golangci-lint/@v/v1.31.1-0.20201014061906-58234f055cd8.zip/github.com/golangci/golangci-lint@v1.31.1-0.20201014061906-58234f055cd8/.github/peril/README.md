Based on https://github.com/gatsbyjs/gatsby/tree/master/peril.

## Update a code

```bash
heroku ps:restart web --app golangci-peril
heroku logs --app golangci-peril -t
```

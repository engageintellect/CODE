char * find_command_name(int pid);
char * find_executable(int pid);
int find_status(int pid);
int get_entry_point(int pid);
